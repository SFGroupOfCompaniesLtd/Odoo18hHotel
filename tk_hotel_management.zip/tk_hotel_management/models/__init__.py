# -*- coding: utf-8 -*-
# Copyright 2020-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from . import room
from . import booking
from . import customer
from . import transport
from . import laundry
from . import housekeeping
from . import restaurant
from . import hall
from . import seasonal_price
from . import res_config_settings_inherit
from . import project_task_inherit
from . import pos_session
from . import pos_order