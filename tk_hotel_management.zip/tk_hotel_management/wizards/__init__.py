# -*- coding: utf-8 -*-
# Copyright 2020-Today TechKhedut.
# Part of TechKhedut. See LICENSE file for full copyright and licensing details.
from . import booking_invoice
from . import booking_report
from . import room_cancellation
from . import room_change
from . import add_extra_people
from . import book_rooms_wizard
